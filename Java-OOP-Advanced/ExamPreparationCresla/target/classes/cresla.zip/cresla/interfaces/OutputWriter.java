package cresla.interfaces;

public interface OutputWriter {
    void write(String output);

    void writeLine(String output);
}

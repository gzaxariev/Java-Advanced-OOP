package cresla.models.module;

import cresla.interfaces.EnergyModule;

public class CryogenRod extends AbstractEnergyModule {

    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
